<?php
class Comum extends AppModel{
    public $name = "Comum";
    /*
    public $validate = array(
    
        'email' => array(
            'rule' => array('minLength', 8),
            'message' => 'Enter a valid email'            
        )
    );
    */
}

