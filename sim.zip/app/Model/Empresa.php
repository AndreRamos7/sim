<?php
class Empresa extends AppModel{
    public $name = "Empresa";
    
}