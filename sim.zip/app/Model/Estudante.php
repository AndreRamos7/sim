<?php
class Estudante extends AppModel{
    public $name = "Estudante";
    
}
