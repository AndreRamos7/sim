<?php
class Gratuito extends AppModel{
    public $name = "Gratuito";
    
}