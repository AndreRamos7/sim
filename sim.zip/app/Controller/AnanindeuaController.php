<?php
class AnanindeuaController extends AppController {

    
    public function index() {

	}
        
   
    
}